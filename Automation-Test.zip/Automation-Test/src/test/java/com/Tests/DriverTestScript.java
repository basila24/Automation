package com.Tests;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.BaseElements.Base;
import com.Pages.CompressorPage;
import com.Pages.HomePage;
import com.Pages.LoginPage;
import com.Utility.ExcelRead;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class DriverTestScript extends Base {
	LoginPage loginPage;
	HomePage homepage;
	CompressorPage compressorPage;
	List<HashMap<String, String>> data = null;
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest test;

	public DriverTestScript() {
		super();
	}

	@BeforeClass
	public void intialsetup() {

		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		htmlReporter = new ExtentHtmlReporter("./reports/extentreports_" + dateName + ".html");
		htmlReporter.config().setDocumentTitle("Automation Report"); // title of report
		htmlReporter.config().setReportName(" Functional Testing"); // name of the report
		htmlReporter.config().setTheme(Theme.STANDARD); // theme of the report
		htmlReporter.start();

		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

		extent.setSystemInfo("Tester Name", "Basith");
		extent.setSystemInfo("Browser", "Chrome");
	}

	
	@BeforeMethod
	public void setUp() {
		driverInit();
		loginPage = new LoginPage();
		homepage = new HomePage();
		compressorPage = new CompressorPage();

	}

	@Test(priority = 0)
	public void ValidateTheCompressorDetails() throws Exception {

		test = extent.createTest("ValidateTheCompressorDetails");
		data = ExcelRead.data(System.getProperty("user.dir") + "//Data//TestData.xlsx", "TestData");
		for (int k = 0; k < data.size(); k++) {

			try {
				navigateToUrl(properties("url"));
				test.log(Status.PASS, "URL navigated successfully  " + properties("url"));
				test.addScreenCaptureFromPath(getScreenshot(driver, "URL navigated successfully " + properties("url")));

			} catch (Exception e) {
				test.log(Status.FAIL, "URL navigated successfully  " + properties("url"));
				test.addScreenCaptureFromPath(getScreenshot(driver, "URL failed to navigate " + properties("url")));
			}
			try {
				loginPage.login(data.get(k).get("EmailID"), data.get(k).get("Password"));
				test.log(Status.PASS, "Application successfully launched and login  " + "\n"
						+ data.get(k).get("EmailID") + "\n" + data.get(k).get("Password"));
				test.addScreenCaptureFromPath(getScreenshot(driver,
						"Login Credential" + data.get(k).get("EmailID") + "\n" + data.get(k).get("Password")));

			} catch (Exception e) {
				test.log(Status.FAIL, "Application successfully launched and login" + data.get(k).get("EmailID") + "\n"
						+ data.get(k).get("Password"));
				test.addScreenCaptureFromPath(getScreenshot(driver,
						"Login Credential" + data.get(k).get("EmailID") + "\n" + data.get(k).get("Password")));
			}

			Assert.assertEquals(homepage.validateLoginPageTitle(), "Homepage | LennoxPROs.com");

			String[] linkName = data.get(k).get("LinkName").split("::");
			for (int i = 0; i < linkName.length; i++) {
				try {
					pageNavigation(linkName[i]);
					landingPageUrlVerification(linkName[i]);
					test.log(Status.PASS, "Page navigated successfully  " + linkName[i]);
					test.addScreenCaptureFromPath(getScreenshot(driver, "Page navigated successfully " + linkName[i]));
				} catch (Exception e) {
					test.log(Status.FAIL, "Page failed to navigate  " + linkName[i]);
					test.addScreenCaptureFromPath(getScreenshot(driver, "Page failed to navigate " + linkName[i]));

				}
			}

			String[] pageNavigation = data.get(k).get("PageNavigation").split("::");
			for (int i = 0; i < pageNavigation.length; i++) {
				try {
					pageNavigation(pageNavigation[i]);
					test.log(Status.PASS, "Page navigated successfully  " + pageNavigation[i]);
					test.addScreenCaptureFromPath(
							getScreenshot(driver, "pageNavigation navigated successfully " + pageNavigation[i]));
				} catch (Exception e) {
					test.log(Status.FAIL, "Page failed to navigate  " + pageNavigation[i]);
					test.addScreenCaptureFromPath(
							getScreenshot(driver, "pageNavigation failed to  navigate " + pageNavigation[i]));
				}

			}

			try {
				Assert.assertEquals(compressorPage.pageDescriptionText(),data.get(k).get("PageDescription"));
				test.log(Status.PASS, "Message verified successfully  " + compressorPage.pageDescriptionText());
				test.addScreenCaptureFromPath(
						getScreenshot(driver, "pageNavigation navigated successfully " ));
			} catch (Exception e1) {
				test.log(Status.FAIL, "Message not  verified successfully  ");
				test.addScreenCaptureFromPath(
						getScreenshot(driver, "pageNavigation failed to  navigate " ));
			}
			
			try {
				categorySelect(k);
				test.log(Status.PASS, "Specified Category selected  ");
				test.addScreenCaptureFromPath(getScreenshot(driver, "pageNavigation navigated successfully  "));
			} catch (IOException e) {
				test.log(Status.FAIL, "pageNavigation failed to  navigate ");
				test.addScreenCaptureFromPath(getScreenshot(driver, ""));
			}

			List<String> expectedDatils = new ArrayList<String>();

			expectedDatils.add(data.get(k).get("Model/Part#"));
			expectedDatils.add(data.get(k).get("Price").trim());
			expectedDatils.add("Bristol H22J38BABC, Reciprocating Compressor, 37,800 Btuh 208/230V, R-22, 1 Phase");
			
			try {
				Assert.assertEquals(compressorPage.addToCartButton(), true, "Add to cart button not enabled");
				test.log(Status.PASS, "AddToCartButton  enabled as expected" );
				test.addScreenCaptureFromPath(
						getScreenshot(driver, "pageNavigation navigated successfully " ));
			} catch (Exception e1) {
				test.log(Status.FAIL, "addToCartButton not enabled  ");
				test.addScreenCaptureFromPath(
						getScreenshot(driver, "pageNavigation failed to  navigate " ));
			}
			
			

			Assert.assertEquals(compressorPage.ProductDetails(), expectedDatils, "Values are not matched");
			
			
			

		}
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
	
	@AfterClass
	public void TearDown() {

		extent.flush();
	}


	private void categorySelect(int k) throws IOException {

		boolean found = false;

		do {

			if (found) {

				compressorPage.categorySelect();

			}
			List<WebElement> s1 = driver.findElements(By.xpath("//span[text()='Cat #: ']/.."));
			for (WebElement s2 : s1) {

				if (s2.getText().substring(6, 12).trim().equals(data.get(k).get("Catalog#").trim())) {

					waitAndClick(s2);

					found = false;
					break;

				} else {

					found = true;
				}
			}
		} while (found);

	}
	
	/*
	 * public String getScreenshot(WebDriver driver, String screenshotName) throws
	 * IOException {
	 * 
	 * 
	 * String dateName= new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
	 * TakesScreenshot ts=(TakesScreenshot)driver; File
	 * s=ts.getScreenshotAs(OutputType.FILE);
	 * 
	 * String destination= System.getProperty("user.dir")+
	 * "./Screenshot/"+dateName+".png"; // htmlReporter = new
	 * ExtentHtmlReporter("./reports/extentreports_" + dateName + ".html"); //
	 * String destination= System.getProperty("user.dir")+ '"+dateName+"' +
	 * "_out.png"; File d=new File(destination); FileUtils.copyFile(s,d);
	 * 
	 * return destination; }
	 */

}
