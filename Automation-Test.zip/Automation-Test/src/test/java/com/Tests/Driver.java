/*
 * package com.Tests;
 * 
 * import java.text.SimpleDateFormat; import java.util.Date; import
 * java.util.HashMap; import java.util.List; import java.util.stream.Collectors;
 * 
 * import org.openqa.selenium.By; import org.openqa.selenium.WebElement; import
 * org.testng.annotations.AfterClass; import org.testng.annotations.BeforeClass;
 * import org.testng.annotations.BeforeMethod; import
 * org.testng.annotations.Listeners; import org.testng.annotations.Test;
 * 
 * import com.ExtendedSeleniumFunctions.Base; import com.Pages.CompressorPage;
 * import com.Pages.HomePage; import com.Pages.LoginPage1; import
 * com.Pages.PageFactory; import com.Utility.ExcelRead; import
 * com.aventstack.extentreports.ExtentReports; import
 * com.aventstack.extentreports.ExtentTest; import
 * com.aventstack.extentreports.reporter.ExtentHtmlReporter; import
 * com.listeners.ExtentReportListener; import com.aventstack.extentreports.*;
 * 
 * // @Listeners(com.listeners.ExtentReport.class) public class Driver extends
 * Base {
 * 
 * 
 * public static void main(String[] args) { List<HashMap<String,String>> a =
 * ExcelRead.data("D:\\Sample.xlsx", "Sheet1");
 * System.out.println(a.get(0).get("Data"));
 * 
 * }
 * 
 * LoginPage1 loginPage1 = new LoginPage1(); CompressorPage compressorPage =
 * PageFactory.getInstance().getcompressorPage(); HomePage homePage = new
 * HomePage(); List<HashMap<String, String>> a = null; static ExtentTest test;
 * static ExtentReports report; public static ExtentHtmlReporter htmlReporter;
 * ExtentTest logInfo = null;
 * 
 * public Driver() { super();
 * 
 * }
 * 
 * @BeforeClass public static void startTest() { report = new ExtentReports();
 * String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
 * htmlReporter = new ExtentHtmlReporter("./reports/extentreports_" + dateName +
 * ".html"); report.attachReporter(htmlReporter); // test =
 * report.createTest("ExtentDemo").createNode("MyFirstChildTest"); }
 * 
 * @BeforeMethod public void BeforeMethod() {
 * 
 * a = ExcelRead.data(System.getProperty("user.dir") + "//Data//TestData.xlsx",
 * "Sheet1"); System.out.println(a.get(0).get("Data"));
 * 
 * }
 * 
 * @Test public void Test1() throws Exception { test =
 * report.createTest("ExtentDemo");// .createNode("MyFirstChildTest"); logInfo =
 * test.createNode("kkkkkkkkkk"); try { driverInit(); //
 * logInfo.pass("details333333333333333"); } catch (Exception e) {
 * logInfo.fail("details"); e.printStackTrace(); }
 * 
 * try { navigateToUrl(properties("url")); logInfo.pass("details111111111111");
 * } catch (Exception e) { logInfo.fail("details222222222222");
 * e.printStackTrace(); } String[] linkName =
 * a.get(0).get("LinkName").split("::"); for (int i = 0; i < linkName.length;
 * i++) { pageNavigation(linkName[i]); landingPageUrlVerification(linkName[i]);
 * }
 * 
 * String[] pageNavigation = a.get(0).get("PageNavigation").split("::"); for
 * (int i = 0; i < pageNavigation.length; i++) {
 * pageNavigation(pageNavigation[i]); //
 * landingPageUrlVerification(pageNavigation[i]); }
 * 
 * compressorPage.categorySelect(); System.out.println("");
 * 
 * }
 * 
 * @AfterClass public static void endTest() {
 * 
 * report.removeTest(test); report.flush();
 * 
 * }
 * 
 * public void categorySelect1() {
 * 
 * boolean found = false;
 * 
 * do {
 * 
 * if (found) {
 * 
 * // waitAndClick(driver.findElement(By.xpath("//li[@class='next']")));
 * compressorPage.categorySelect();
 * 
 * } List<WebElement> s1 =
 * driver.findElements(By.xpath("//span[text()='Cat #: ']/..")); for (WebElement
 * s2 : s1) {
 * 
 * if (s2.getText().substring(6,
 * 12).trim().equals(a.get(0).get("Catalog#").trim())) {
 * 
 * waitAndClick(s2); found = false; break;
 * 
 * } else {
 * 
 * found = true; } } } while (found);
 * 
 * }
 * 
 * }
 */