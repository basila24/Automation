package com.Pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseElements.Base;

public class CompressorPage extends Base {

	@FindBy(xpath = "//li[@class='next']")
	WebElement pagination;
	
	@FindBy(xpath = "//div[contains(@class,'product-content')]//h1")
	WebElement productDescription;
	
	@FindBy(xpath = "//div[contains(@class,'product-content')]//p[2]")
	WebElement modelPart;
	
	@FindBy(xpath = "//div[contains(@class,'product-content')]//p[1]")
	WebElement category;
	
	@FindBy(xpath = "//div[contains(@class,'product-content')]//div//p")
	WebElement price;
	
	@FindBy(xpath = "//li[@class='next']")
	WebElement standardShippingAvailablity;
	
	@FindBy(xpath = "//li[@class='next']")
	WebElement pickOnStoreAvailablity;
	
	@FindBy(xpath = "//button[contains(@id,'product-button')]")
	WebElement addToCartButton;
	
	@FindBy(xpath = "//div[@class='description']")
	WebElement pageDescription;
	

	// Initializing the Page Objects:
	public CompressorPage() {
		PageFactory.initElements(driver, this);
	}

	public String pageDescriptionText() throws Exception {

		return getText(pageDescription);

	}
	
	public void categorySelect() {

		waitAndClick(pagination);

	}
	
	public List<String> ProductDetails() throws Exception {

		List<String> details = new ArrayList<String>();
		
		
		details.add(getText(modelPart).split(":")[1].trim());
		details.add(getText(price).trim());
		details.add(getText(productDescription));
		
		return details;

	}
	
	public boolean addToCartButton() {

		return addToCartButton.isEnabled();

	}
	
	

}
