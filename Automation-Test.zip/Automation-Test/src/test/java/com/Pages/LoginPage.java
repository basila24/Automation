package com.Pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseElements.Base;

public class LoginPage extends Base {

	// Page Factory - OR:
	@FindBy(xpath = "//a[text()='Sign In']")
	WebElement signinLink;

	@FindBy(name = "j_username")
	WebElement username;

	@FindBy(name = "j_password")
	WebElement password;

	@FindBy(id = "loginSubmit")
	WebElement loginBtn;

	@FindBy(xpath = "//li[@class='next']")
	WebElement pagination;

	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	public String validateLoginPageTitle() {
		return driver.getTitle();
	}

	public HomePage login(String user, String pwd) {
		waitAndClick(signinLink);
		username.sendKeys(user);
		password.sendKeys(pwd);
		waitAndClick(loginBtn);

		return new HomePage();
	}

}
