package com.Pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.BaseElements.Base;


public class HomePage extends Base{
	
	
	
		public HomePage(){
		PageFactory.initElements(driver, this);
	}
	
	
		public String validateLoginPageTitle() {
			return driver.getTitle();
		}
	

	
	

	
	
	
}
