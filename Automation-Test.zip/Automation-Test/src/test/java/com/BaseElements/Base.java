package com.BaseElements;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public abstract class Base {

	public static WebDriver driver;
	static String path = System.getProperty("user.dir");

	// driver initialize -------------------------------
	public static WebDriver driverInit() {
		System.setProperty("webdriver.chrome.driver", path + "//driver//chromedriver.exe");
		Map<String, Object> prefs = new HashMap<String, Object>();

		prefs.put("safebrowsing.enabled", true);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);

		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		return driver;
	}

	public static String properties(String value) throws Exception {

		File location = new File(path + "//src//test//resources//configuration.properties");
		String name = null;
		Properties properties = new Properties();
		FileInputStream stream = new FileInputStream(location);
		properties.load(stream);
		name = properties.getProperty(value);

		return name;
	}

	public static void navigateToUrl(String url) {
		try {
			driver.get(url);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void pageNavigation(String pages) {
		try {
			waitAndClick(driver.findElement(By.xpath("//a[contains(text() ,'" + pages + "')]")));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void landingPageUrlVerification(String pages) {
		try {
			driver.getCurrentUrl().contains(pages);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean waitAndClick(WebElement element) {

		boolean Found = false;
		long startTime = System.currentTimeMillis();
		long elapsedTime = 0;
		while (elapsedTime < 20 * 1000 && !Found) {
			try {

				if (!element.isDisplayed()) {
					Found = false;
				} else {
					new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(element));
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
					element.click();
					Found = true;
				}
			} catch (Exception e) {
				Found = false;

			}
			elapsedTime = (new Date()).getTime() - startTime;
		}

		return Found;
	}

	public static String getText(WebElement element) throws Exception {
		String text = null;
		try {
			waitForElementVisibility(element);
			if (element.getText() != null) {
				text = element.getText();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return text;

	}

	public static void waitForElementVisibility(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public String getScreenshot(WebDriver driver, String screenshotName) throws IOException {

		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot) driver;
		File s = ts.getScreenshotAs(OutputType.FILE);

		// String destination=
		// System.getProperty("user.dir"+"/Screenshot/"+screenshotName+dateName+".png");
		String destination = System.getProperty("user.dir") + "/screenshot" + "+dateName+" + "_out.png";
		File d = new File(destination);
		FileUtils.copyFile(s, d);

		return destination;
	}

}
